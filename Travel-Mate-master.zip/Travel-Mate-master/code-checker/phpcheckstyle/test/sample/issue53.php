<?php 
if (time() == 4) 
	echo "test";
else {
	echo "hallo";
}