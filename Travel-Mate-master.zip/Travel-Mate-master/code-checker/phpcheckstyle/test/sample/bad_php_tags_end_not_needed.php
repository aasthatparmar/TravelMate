<?  // 1 noShortPhpCodeTag -  should be <?php :: PHPCHECKSTYLE_WRONG_OPEN_TAG

/**
* This file is an exemple of PHP file containing bad tag usage.
* This test file should generate 2 warnings with the default config.
*/

// 2 noFileCloseTag : End tag not needed :: PHPCHECKSTYLE_END_FILE_CLOSE_TAG
?>