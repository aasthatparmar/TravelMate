<?php 

$DB =& new $driver($params); 

