<?php
/**
 * Test 4 spaces indentation.
 * @SuppressWarnings localScopeVariableLength
 */
class Indentation {

    /**
     * Test.
     */
    function foo() {

        $a = 0;

        //code
        if ($a === 1) {
            // new code
            echo "toto";
        }

    }

}