<?php
/**
 * TODO : The todo message.
 *
 * @param String $var a var
 * @SuppressWarnings localScopeVariableLength
 */
function toto($a) {
	$a = 1;
}