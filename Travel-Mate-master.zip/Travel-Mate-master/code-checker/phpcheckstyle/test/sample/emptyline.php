<?php
/*

*/
$a = 1; // this is line 5, but the warning is for line 4