 <?php

	/**
  * Model Base class
  */
	class ModelBase {

		/**
		 * Validate a date.
		 */
		public function __toString() {
			return "toto";
		}
	}