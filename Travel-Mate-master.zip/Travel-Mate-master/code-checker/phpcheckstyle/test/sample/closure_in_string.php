<?php
$a = "test {$hello} test";