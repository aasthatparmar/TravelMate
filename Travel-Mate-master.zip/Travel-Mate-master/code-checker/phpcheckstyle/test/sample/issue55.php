<?php 
$var = 'none';
switch ($var) {
	case "xml":
		break;
	case "json":
		break;
	default:
		break;
}
?>