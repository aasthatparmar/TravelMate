<?php
/**
 * Unterminated comment.
 * Should generate a PHP Exception : Unterminated comment starting line 2
 * 
 