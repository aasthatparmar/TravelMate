<?php

/**
* This test file should generate 1 warnings with the default config.
*/

// 1 noFileFinishHTML : Some text after the last end tag  :: PHPCHECKSTYLE_END_FILE_INLINE_HTML

?> test