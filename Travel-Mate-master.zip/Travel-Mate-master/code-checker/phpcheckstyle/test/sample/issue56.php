<?php 
/** @SuppressWarnings needBraces */
if (!defined('CONSTANT')) exit;

if ($toto == 1) exit;

/* End of file: ./path/to/file.php */