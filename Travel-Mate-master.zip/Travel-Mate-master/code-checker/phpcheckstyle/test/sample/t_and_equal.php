<?php
$obj =& get_instance();
?>